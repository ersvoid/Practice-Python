# dice_and_coin_flip

Probably Probability

Coin flip and various-sided dice simulation.

Choose between a coin flip, a 4, 6, 8, 10, or 12-sided die, or generate a random percentage value.
