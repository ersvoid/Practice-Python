# Caves-of-Madness-Game
Text-based fantasy game

Final Capstone Project for Udemy.com Course:

Complete Python Bootcamp: Go from zero to hero in python


The Caves of Madness are an immense cavern system that goes all the way down to Hell.
Every decade, the town that sits at the entrance to the cave must send forth warriors
or be plagued by the evil demons.

The time has come. The drums are sounding in the deep.

You must fight off the neverending hordes!
