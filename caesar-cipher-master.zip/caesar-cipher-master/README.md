# caesar-cipher
Encryption/Decryption of Single Word using Caesar Cipher

Encryption
1. User enters a word
2. User chooses a key from 1 to 26
3. Each letter is shifter forward through the alphabet according to the key
4. The encrypted word is printed out.

Decryption
1. User inputs the encrypted word
2. User inputs a key from 1 to 26
3. Each letter is shifted backwards through the alphabet according to the key
4. The decrypted word is printed out.
