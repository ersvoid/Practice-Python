# Blackjack-Game
A simple game of Blackjack in Python 3
Date: 2/5/2008
Author: Eric Stinson
For: Complete Python Bootcamp: Go from zero to hero in Python (Udemy.com Course)
Instructor: Jose Portilla
