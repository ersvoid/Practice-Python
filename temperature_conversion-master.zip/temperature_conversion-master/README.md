# temperature_conversion

A Final Capstone Project for Udemy.com Course: From Zero to Hero in Python

Temperature Conversion Calculator
Instructions:
1. Choose an initial temperature unit by the associated number.
2. Input the temperature value.
3. Choose the temperature unit to convert to by the associated number.
4. Final print statement displays converted temperature.
